package gmaps

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/gosom/scrapemate"
	"github.com/gosom/scrapemate/adapters/fetchers/stealth"
)

type fetchReviewsParams struct {
	page        scrapemate.BrowserPage
	mapURL      string
	reviewCount int
	capture     *browserReviewCapture
}

type FetchReviewsResponse struct {
	pages      [][]byte
	collection ReviewCollection
}

type fetcher struct {
	httpClient scrapemate.HTTPFetcher
	params     fetchReviewsParams
}

func newReviewFetcher(params fetchReviewsParams) *fetcher {
	netClient := stealth.New("firefox", nil)
	ans := fetcher{
		params:     params,
		httpClient: netClient,
	}

	return &ans
}

func (f *fetcher) fetch(ctx context.Context) (FetchReviewsResponse, error) {
	requestIDForSession, err := generateRandomID(21)
	if err != nil {
		return FetchReviewsResponse{}, fmt.Errorf("failed to generate session request ID: %v", err)
	}

	reviewURL, err := f.generateURL(f.params.mapURL, "", 20, requestIDForSession)
	if err != nil {
		return FetchReviewsResponse{}, fmt.Errorf("failed to generate initial URL: %v", err)
	}

	// First, try to fetch using the browser's session (has cookies/authentication)
	if f.params.page != nil {
		ans, err := f.fetchWithBrowser(ctx, reviewURL, requestIDForSession)
		if err == nil && len(ans.pages) > 0 {
			return ans, nil
		}

		log.Printf("Browser-based RPC fetch failed: %v, trying HTTP", err)
	}

	// Fallback to direct HTTP (may fail due to lack of authentication)
	currentPageBody, err := f.fetchReviewPage(ctx, reviewURL)
	if err != nil {
		log.Printf("RPC fetch failed, will try DOM extraction: %v", err)
		return FetchReviewsResponse{}, err
	}

	ans := FetchReviewsResponse{}
	ans.pages = append(ans.pages, currentPageBody)

	nextPageToken := extractNextPageToken(currentPageBody)

	for nextPageToken != "" {
		reviewURL, err = f.generateURL(f.params.mapURL, nextPageToken, 20, requestIDForSession)
		if err != nil {
			log.Printf("Error generating URL for token %s: %v", nextPageToken, err)
			break
		}

		currentPageBody, err = f.fetchReviewPage(ctx, reviewURL)
		if err != nil {
			log.Printf("Error fetching review page with token %s: %v", nextPageToken, err)
			break
		}

		ans.pages = append(ans.pages, currentPageBody)
		nextPageToken = extractNextPageToken(currentPageBody)
	}

	return ans, nil
}

// fetchWithBrowser uses Playwright to fetch the review API with browser cookies
func (f *fetcher) fetchWithBrowser(_ context.Context, initialURL, requestID string) (FetchReviewsResponse, error) {
	ans := FetchReviewsResponse{}
	page := f.params.page

	// Use JavaScript fetch to get the reviews with proper cookies
	jsCode := fmt.Sprintf(`async () => {
		try {
			const response = await fetch('%s', {
				method: 'GET',
				credentials: 'include',
				headers: {
					'Accept': '*/*',
					'Accept-Language': 'en-US,en;q=0.9'
				}
			});
			if (!response.ok) {
				return { error: 'HTTP ' + response.status };
			}
			const text = await response.text();
			return { data: text };
		} catch (e) {
			return { error: e.message };
		}
	}`, initialURL)

	result, err := page.Eval(jsCode)
	if err != nil {
		return ans, fmt.Errorf("browser fetch failed: %w", err)
	}

	resultMap, ok := result.(map[string]interface{})
	if !ok {
		return ans, fmt.Errorf("unexpected result type: %T", result)
	}

	if errMsg, hasError := resultMap["error"]; hasError {
		return ans, fmt.Errorf("fetch error: %v", errMsg)
	}

	data, ok := resultMap["data"].(string)
	if !ok || len(data) < 10 {
		return ans, fmt.Errorf("empty response from browser fetch")
	}

	ans.pages = append(ans.pages, []byte(data))

	// Get additional pages
	nextPageToken := extractNextPageToken([]byte(data))
	for nextPageToken != "" && len(ans.pages) < 50 { // Limit to 50 pages
		nextURL, err := f.generateURL(f.params.mapURL, nextPageToken, 20, requestID)
		if err != nil {
			break
		}

		jsCode = fmt.Sprintf(`async () => {
			try {
				const response = await fetch('%s', {
					method: 'GET',
					credentials: 'include'
				});
				if (!response.ok) {
					return { error: 'HTTP ' + response.status };
				}
				return { data: await response.text() };
			} catch (e) {
				return { error: e.message };
			}
		}`, nextURL)

		result, err = page.Eval(jsCode)
		if err != nil {
			break
		}

		resultMap, ok = result.(map[string]interface{})
		if !ok || resultMap["error"] != nil {
			break
		}

		data, ok = resultMap["data"].(string)
		if !ok || len(data) < 10 {
			break
		}

		ans.pages = append(ans.pages, []byte(data))
		nextPageToken = extractNextPageToken([]byte(data))
	}

	return ans, nil
}

var (
	patternsOnce sync.Once
	patterns     map[string]*regexp.Regexp
)

const hexMatchPattern = `0x[0-9a-fA-F]+:0x[0-9a-fA-F]+` // Hex format place ID

// extractPlaceID extracts the place ID from various Google Maps URL formats
func extractPlaceID(mapURL string) (string, error) {
	patternsOnce.Do(func() {
		patterns = make(map[string]*regexp.Regexp)
		// Try multiple patterns for extracting place ID
		avail := []string{
			`!1s([^!]+)`,                             // Standard format: !1s0x...
			`place_id=([^&]+)`,                       // Query parameter format
			`/place/[^/]+/@[^/]+/data=!.*!1s([^!]+)`, // Full place URL
			hexMatchPattern,                          // Hex format place ID
		}

		patterns = make(map[string]*regexp.Regexp)
		for _, p := range avail {
			patterns[p] = regexp.MustCompile(p)
		}
	})

	for pattern, re := range patterns {
		match := re.FindStringSubmatch(mapURL)
		if len(match) >= 2 {
			rawPlaceID, err := url.QueryUnescape(match[1])
			if err != nil {
				rawPlaceID = match[1]
			}

			return rawPlaceID, nil
		}
		// For hex format, match[0] is the full match
		if pattern == hexMatchPattern && len(match) >= 1 {
			return match[0], nil
		}
	}

	return "", fmt.Errorf("could not extract place ID from URL: %s", mapURL)
}

func (f *fetcher) generateURL(mapURL, pageToken string, pageSize int, requestID string) (string, error) {
	rawPlaceID, err := extractPlaceID(mapURL)
	if err != nil {
		return "", err
	}

	encodedPlaceID := url.QueryEscape(rawPlaceID)
	encodedPageToken := url.QueryEscape(pageToken)

	// Updated pb components based on current Google Maps API format (Dec 2025)
	pbComponents := []string{
		fmt.Sprintf("!1m6!1s%s", encodedPlaceID),
		"!6m4!4m1!1e1!4m1!1e3",
		fmt.Sprintf("!2m2!1i%d!2s%s", pageSize, encodedPageToken),
		fmt.Sprintf("!5m2!1s%s!7e81", requestID),
		"!8m9!2b1!3b1!5b1!7b1",
		"!12m4!1b1!2b1!4m1!1e1!11m0!13m1!1e1",
	}

	// Use English language for consistent parsing
	fullURL := fmt.Sprintf(
		"https://www.google.com/maps/rpc/listugcposts?authuser=0&hl=en&pb=%s",
		strings.Join(pbComponents, ""),
	)

	return fullURL, nil
}

func (f *fetcher) fetchReviewPage(ctx context.Context, u string) ([]byte, error) {
	job := scrapemate.Job{
		Method: requestMethodGet,
		URL:    u,
	}

	resp := f.httpClient.Fetch(ctx, &job)
	if resp.Error != nil {
		return nil, fmt.Errorf("fetch error for %s: %w", u, resp.Error)
	}

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("%s: unexpected status code: %d", u, resp.StatusCode)
	}

	return resp.Body, nil
}

func extractNextPageToken(data []byte) string {
	text := string(data)
	prefix := ")]}'\n"
	text = strings.TrimPrefix(text, prefix)

	var result []interface{}

	err := json.Unmarshal([]byte(text), &result)
	if err != nil {
		return ""
	}

	if len(result) < 2 || result[1] == nil {
		return ""
	}

	token, ok := result[1].(string)
	if !ok {
		return ""
	}

	return token
}

func generateRandomID(length int) (string, error) {
	numBytes := (length*6 + 7) / 8
	if numBytes < 16 {
		numBytes = 16
	}

	b := make([]byte, numBytes)

	_, err := rand.Read(b)
	if err != nil {
		return "", err
	}

	encoded := base64.URLEncoding.WithPadding(base64.NoPadding).EncodeToString(b)
	if len(encoded) >= length {
		return encoded[:length], nil
	}

	return "", errors.New("generated ID is shorter than expected")
}

// DOMReview represents a review extracted from the DOM
type DOMReview struct {
	ReviewID                string
	AuthorName              string
	AuthorURL               string
	ProfilePicture          string
	Rating                  int
	RelativeTimeDescription string
	Text                    string
	Images                  []string
}

// ConvertDOMReviewsToReviews converts DOMReview slice to Review slice
func ConvertDOMReviewsToReviews(domReviews []DOMReview) []Review {
	reviews := make([]Review, 0, len(domReviews))

	for i := range domReviews {
		dr := &domReviews[i]
		review := Review{
			Name:           dr.AuthorName,
			ProfilePicture: dr.ProfilePicture,
			Rating:         dr.Rating,
			Description:    dr.Text,
			When:           dr.RelativeTimeDescription,
			Images:         dr.Images,
			ReviewID:       dr.ReviewID,
		}

		if review.Name != "" {
			reviews = append(reviews, review)
		}
	}

	return reviews
}

// dedupeDOMReviewsAgainstPrimary drops DOM reviews that are already present in the
// primary reviews. Matching is by review id only, an empty id is never a duplicate.
func dedupeDOMReviewsAgainstPrimary(primary, domReviews []Review) []Review {
	seen := make(map[string]struct{}, len(primary))

	for i := range primary {
		if primary[i].ReviewID != "" {
			seen[primary[i].ReviewID] = struct{}{}
		}
	}

	if len(seen) == 0 {
		return domReviews
	}

	kept := make([]Review, 0, len(domReviews))
	withID := 0

	for i := range domReviews {
		if domReviews[i].ReviewID != "" {
			withID++

			if _, dup := seen[domReviews[i].ReviewID]; dup {
				continue
			}
		}

		kept = append(kept, domReviews[i])
	}

	if withID > 0 && len(kept) == len(domReviews) {
		log.Printf("DOM review ids matched none of %d primary ids", len(seen))
	}

	return kept
}

func decodeDOMReviews(raw []any) []DOMReview {
	decoded := make([]DOMReview, 0, len(raw))

	for _, rawReview := range raw {
		reviewMap, ok := rawReview.(map[string]interface{})
		if !ok {
			continue
		}

		review := DOMReview{}
		if v, ok := reviewMap["review_id"].(string); ok {
			review.ReviewID = v
		}

		if v, ok := reviewMap["author_name"].(string); ok {
			review.AuthorName = v
		}

		if v, ok := reviewMap["author_url"].(string); ok {
			review.AuthorURL = v
		}

		if v, ok := reviewMap["profile_picture"].(string); ok {
			review.ProfilePicture = v
		}

		// Playwright decodes whole JS numbers as int, fractional ones as float64.
		switch v := reviewMap["rating"].(type) {
		case int:
			review.Rating = v
		case float64:
			review.Rating = int(v)
		}

		// The rating selectors also match non-star aria-labels, e.g. "12 reviews".
		if review.Rating < 1 || review.Rating > 5 {
			review.Rating = 0
		}

		if v, ok := reviewMap["relative_time_description"].(string); ok {
			review.RelativeTimeDescription = v
		}

		if v, ok := reviewMap["text"].(string); ok {
			review.Text = v
		}

		if v, ok := reviewMap["images"].([]interface{}); ok {
			for _, img := range v {
				if imgStr, ok := img.(string); ok {
					review.Images = append(review.Images, imgStr)
				}
			}
		}

		decoded = append(decoded, review)
	}

	return decoded
}

// extractReviewsFromPage extracts reviews directly from the page DOM
// This is a fallback when the RPC API fails
func extractReviewsFromPage(ctx context.Context, page scrapemate.BrowserPage, maxReviews int, states ...*reviewExtractionState) ([]DOMReview, error) {
	state := &reviewExtractionState{}
	if len(states) > 0 && states[0] != nil {
		state = states[0]
	}

	if err := ctx.Err(); err != nil {
		return nil, err
	}

	log.Printf("Attempting DOM-based review extraction")

	// First, try to click the reviews section to open the reviews panel
	clickedReviews, _ := page.Eval(`() => {
		try {
			const triggerClick = (el) => {
				if (!el) return false;
				el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
				el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
				el.click();
				return true;
			};

			// Method 1: Click on the reviews tab if already visible
			const tabs = document.querySelectorAll('button[role="tab"]');
			for (const tab of tabs) {
				const label = (tab.getAttribute('aria-label') || tab.textContent || '').toLowerCase();
				if (label.includes('review')) {
					if (tab.getAttribute('aria-selected') !== 'true') triggerClick(tab);
					return 'reviews_tab';
				}
			}

			// Method 2: Click the star rating area or reviews count in place info
			const ratingArea = document.querySelector('.F7nice, .fontDisplayLarge');
			if (ratingArea) {
				const btn = ratingArea.querySelector('button') || ratingArea.closest('button') || ratingArea;
				triggerClick(btn);
				return 'rating_area';
			}

			// Method 3: Look for "See all reviews" or similar links/buttons
			const allLinks = document.querySelectorAll('a, button');
			for (const link of allLinks) {
				const text = (link.getAttribute('aria-label') || link.textContent || '').toLowerCase();
				if (text.includes('all review') || text.includes('see review') || text.includes('more review')) {
					triggerClick(link);
					return 'all_reviews_link';
				}
			}

			// Method 4: Click on buttons with review jsaction
			const reviewsButtons = document.querySelectorAll('button[jsaction*="reviewChart"], button[jsaction*="reviews"]');
			for (const btn of reviewsButtons) {
				triggerClick(btn);
				return 'reviews_button';
			}

			return false;
		} catch (e) {
			console.error('Error clicking reviews:', e);
			return false;
		}
	}`)

	if clickedReviews != nil && clickedReviews != false {
		log.Printf("Clicked reviews via: %v", clickedReviews)
	}

	// Wait for reviews panel to load
	const reviewsWaitTimeout = 5 * time.Second

	_ = page.WaitForSelector(".jftiEf, div[data-review-id]", reviewsWaitTimeout)

	// In case clicking the rating revealed a new "Reviews" tab, ensure the Reviews tab is selected
	_, _ = page.Eval(`() => {
		const triggerClick = (el) => {
			if (!el) return false;
			el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
			el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
			el.click();
			return true;
		};
		const tabs = document.querySelectorAll('button[role="tab"]');
		for (const tab of tabs) {
			const label = (tab.getAttribute('aria-label') || tab.textContent || '').toLowerCase();
			if (label.includes('review') && tab.getAttribute('aria-selected') !== 'true') {
				triggerClick(tab);
				return true;
			}
		}
		return false;
	}`)
	// The tab may have been mounted by the first click. Wait again after
	// selecting it rather than scrolling the place overview while it loads.
	_ = page.WaitForSelector(".jftiEf, div[data-review-id]", reviewsWaitTimeout)

	var reviews []DOMReview

	var seen domReviewSet

	const defaultMaxScrollAttempts = 50

	maxScrollAttempts := defaultMaxScrollAttempts

	if maxReviews > 0 {
		// Each scroll pass on Google Maps typically yields ~10 new reviews
		needed := (maxReviews / 10) + 10
		if needed > maxScrollAttempts {
			maxScrollAttempts = needed
		}

		const absoluteMaxScrollAttempts = 150
		if maxScrollAttempts > absoluteMaxScrollAttempts {
			maxScrollAttempts = absoluteMaxScrollAttempts
		}
	}

	lastCount := 0
	stuckCount := 0

	for attempt := 0; attempt < maxScrollAttempts; attempt++ {
		select {
		case <-ctx.Done():
			return reviews, ctx.Err()
		default:
		}

		// Extract reviews from the DOM - updated for Dec 2025 Google Maps structure
		reviewsJSON, err := page.Eval(`() => {
			try {
				const reviews = [];

				// Try multiple selectors for review container elements
				// Google Maps uses various class names that change over time
				const reviewSelectors = [
					'.jJc9Ad',
					'.jftiEf',                           // Common review container
					'div[data-review-id]',               // Review with ID attribute
					'.gws-localreviews__google-review',  // Alternative format
					'[data-hveid] .review-dialog-list > div', // Search results reviews
					'.WMbnJf',                           // Another review container
					'.bwb7ce',                           // New review format
				];

				let reviewElements = [];
				for (const selector of reviewSelectors) {
					const elements = document.querySelectorAll(selector);
					if (elements && elements.length > 0) {
						reviewElements = Array.from(elements);
						console.log('Found reviews with selector:', selector, 'count:', elements.length);
						break;
					}
				}

				// If no reviews found with specific selectors, try to find by structure
				if (reviewElements.length === 0) {
					// Look for elements that look like reviews (have rating + text)
					const allDivs = document.querySelectorAll('div[class]');
					for (const div of allDivs) {
						const hasRating = div.querySelector('[aria-label*="star"], [role="img"][aria-label*="star"]');
						const hasText = div.querySelector('span.wiI7pd, span[class*="review"]');
						if (hasRating && hasText && !reviewElements.includes(div)) {
							reviewElements.push(div);
						}
					}
				}

				console.log('Total review elements found:', reviewElements.length);

				for (const element of reviewElements) {
					try {
						// The card carries the id, unless the selector matched a wrapper
						const reviewId = element.getAttribute('data-review-id') ||
							element.querySelector('[data-review-id]')?.getAttribute('data-review-id') || '';

						// Author name - comprehensive selectors
						const userSelectors = [
							'.d4r55',           // Primary name class
							'.WNxzHc',          // Alternative name
							'.TSUbDb a',        // Link with name
							'.review-author',   // Generic
							'button.al6Kxe',    // Clickable name
							'.bHrnEe',          // Another name container
						];
						let userName = '';
						let userUrl = '';
						for (const sel of userSelectors) {
							const el = element.querySelector(sel);
							if (el) {
								userName = el.textContent?.trim() || '';
								if (el.tagName?.toLowerCase() === 'a') {
									userUrl = el.getAttribute('href') || '';
								}
								if (userName) break;
							}
						}

						// Profile picture - multiple patterns
						const profilePicSelectors = [
							'.NBa7we',
							'img[src*="googleusercontent"]',
							'img[src*="lh3.google"]',
							'.review-author-photo img',
						];
						let profilePic = '';
						for (const sel of profilePicSelectors) {
							const el = element.querySelector(sel);
							if (el) {
								profilePic = el.getAttribute('src') || '';
								if (profilePic) break;
							}
						}

						// Rating - try multiple approaches
						let rating = 0;
						const ratingSelectors = [
							'.kvMYJc',
							'.DU9Pgb span[aria-label]',
							'[role="img"][aria-label*="star"]',
							'.pjemBf span',
							'.review-score',
						];
						for (const sel of ratingSelectors) {
							const ratingEl = element.querySelector(sel);
							if (ratingEl) {
								const ariaLabel = ratingEl.getAttribute('aria-label') || '';
								// Match patterns like "5 stars", "Rated 4 out of 5", "4.5 étoiles"
								const match = ariaLabel.match(/(\d+(?:\.\d+)?)/);
								if (match) {
									rating = Math.round(parseFloat(match[1])) || 0;
									break;
								}
								// Also try counting filled stars
								const filledStars = element.querySelectorAll('.hCCjke.vzX5Ic, [aria-label*="star"][style*="color"]').length;
								if (filledStars > 0) {
									rating = filledStars;
									break;
								}
							}
						}

						// Time/date - multiple selectors
						const timeSelectors = ['.rsqaWe', '.DU9Pgb', '.tTVLSc', '.review-date', '.dehysf'];
						let relativeTime = '';
						for (const sel of timeSelectors) {
							const el = element.querySelector(sel);
							if (el) {
								const text = el.textContent?.trim() || '';
								// Look for time-related text (ago, month, year, etc)
								if (text && (text.includes('ago') || text.includes('week') || text.includes('month') ||
								    text.includes('year') || text.includes('day') || text.match(/\d{4}/))) {
									relativeTime = text;
									break;
								}
							}
						}

						// Review text - try to expand and get full text
						const textSelectors = [
							'.wiI7pd',
							'.MyEned span',
							'.review-full-text',
							'.Jtu6Td span',
							'[data-expandable-section] span',
						];
						let text = '';

						// First try to click "More" button to expand text
						const moreButtons = element.querySelectorAll('.w8nwRe, button[aria-label*="More"], button[aria-expanded="false"]');
						for (const btn of moreButtons) {
							try { btn.click(); } catch(e) {}
						}

						for (const sel of textSelectors) {
							const textEl = element.querySelector(sel);
							if (textEl) {
								text = textEl.textContent?.trim() || '';
								if (text && text.length > 5) break;
							}
						}

						// Images
						const imageElements = element.querySelectorAll('.KtCyie img, .Tya61d img, .review-photos img, img[src*="lh3"]');
						const images = [];
						for (const img of imageElements) {
							const src = img.getAttribute('src') || '';
							if (src && !src.includes('data:image') && !src.includes('profile')) {
								images.push(src);
							}
						}

						if (userName && (text || rating > 0)) {
							reviews.push({
								review_id: reviewId,
								author_name: userName,
								author_url: userUrl,
								profile_picture: profilePic,
								rating: rating,
								relative_time_description: relativeTime,
								text: text,
								images: images
							});
						}
					} catch (e) {
						console.error("Error extracting review:", e);
					}
				}

				const limited = document.body.innerText.includes("You're seeing a limited view of Google Maps");
				return {reviews, limited};
			} catch (e) {
				console.error("Error in review extraction:", e);
				return [];
			}
		}`)
		if err != nil {
			log.Printf("Error extracting reviews from DOM: %v", err)
		} else {
			decoded, limited := decodeReviewSnapshot(reviewsJSON)
			state.limited = state.limited || limited
			reviews = seen.add(reviews, decoded, maxReviews)
		}

		currentCount := len(reviews)

		state.capture.drain(ctx)

		if state.capture != nil {
			state.limited = state.limited || state.capture.limited
			currentCount = max(currentCount, len(state.capture.ids))
		}

		if maxReviews > 0 && currentCount >= maxReviews {
			state.reason = "limit_reached"

			log.Printf("DOM extraction reached target of %d reviews (found %d)", maxReviews, currentCount)

			break
		}

		if state.limited && currentCount > 0 {
			state.reason = reviewReasonLimited

			log.Printf("Anonymous review access is limited; preserving %d available reviews", currentCount)

			break
		}

		if currentCount == lastCount {
			stuckCount++

			const maxConsecutiveStuck = 5
			if stuckCount >= maxConsecutiveStuck {
				state.reason = "no_more_reviews"

				log.Printf("Review count stuck at %d, stopping scroll", currentCount)

				break
			}
		} else {
			stuckCount = 0
			lastCount = currentCount
		}

		// Scroll to load more reviews
		_, _ = page.Eval(`() => {
			try {
				// 1. Walk up from review card to find the true scrollable container
				const card = document.querySelector('.jJc9Ad, .jftiEf, div[data-review-id]');
				if (card) {
					let el = card.parentElement;
					while (el && el !== document.body) {
						const st = window.getComputedStyle(el);
						if ((st.overflowY === 'auto' || st.overflowY === 'scroll') && el.scrollHeight > el.clientHeight && el.clientHeight > 100) {
							el.scrollTop += Math.max(100, el.clientHeight * 0.8);
							el.dispatchEvent(new Event('scroll', { bubbles: true }));
							return true;
						}
						el = el.parentElement;
					}
				}

				// 2. Try known scrollable containers that actually have scrollable content
				const selectors = [
					'div[role="feed"]',
					'.m6QErb.DxyBCb.kA9KIf.dS8AEf',
					'.m6QErb.DxyBCb.kA9KIf',
					'.DxyBCb.kA9KIf',
					'.section-scrollbox',
					'.m6QErb'
				];

				for (const selector of selectors) {
					const elements = document.querySelectorAll(selector);
					for (const el of elements) {
						if (el.scrollHeight > el.clientHeight && el.clientHeight > 100) {
							el.scrollTop += Math.max(100, el.clientHeight * 0.8);
							el.dispatchEvent(new Event('scroll', { bubbles: true }));
							return true;
						}
					}
				}

				window.scrollBy(0, 800);
				return true;
			} catch (e) {
				window.scrollBy(0, 800);
				return false;
			}
		}`)

		const scrollWaitDuration = 1 * time.Second

		timer := time.NewTimer(scrollWaitDuration)
		select {
		case <-ctx.Done():
			timer.Stop()
			return reviews, ctx.Err()
		case <-timer.C:
		}
	}

	log.Printf("DOM extraction completed: %d reviews found", len(reviews))

	return reviews, nil
}

// FetchReviewsWithFallback collects anonymous browser-generated review responses
// alongside a DOM fallback. Callers without a browser retain the legacy HTTP path.
func FetchReviewsWithFallback(ctx context.Context, params fetchReviewsParams) (FetchReviewsResponse, []DOMReview, error) {
	if params.page != nil {
		return collectBrowserReviews(ctx, params)
	}

	fetcher := newReviewFetcher(params)

	// Try RPC-based extraction first
	rpcResponse, err := fetcher.fetch(ctx)
	if err == nil && len(rpcResponse.pages) > 0 {
		// Validate that we actually got reviews
		totalReviews := 0

		for _, page := range rpcResponse.pages {
			reviews := extractReviews(page)
			totalReviews += len(reviews)
		}

		if totalReviews > 0 {
			log.Printf("RPC extraction successful: %d review pages, ~%d reviews", len(rpcResponse.pages), totalReviews)
			return rpcResponse, nil, nil
		}

		log.Printf("RPC returned empty reviews, trying DOM extraction")
	}

	// Return whatever we have
	if err != nil {
		return FetchReviewsResponse{}, nil, fmt.Errorf("all review extraction methods failed: %v", err)
	}

	return rpcResponse, nil, nil
}

func collectBrowserReviews(ctx context.Context, params fetchReviewsParams) (FetchReviewsResponse, []DOMReview, error) {
	capture := params.capture
	if capture == nil {
		capture = startReviewCapture(params.page)
		defer capture.close()
	}

	state := &reviewExtractionState{capture: capture}
	domReviews, err := extractReviewsFromPage(ctx, params.page, params.reviewCount, state)
	capture.drain(ctx)

	response := FetchReviewsResponse{collection: ReviewCollection{Method: "dom", Reason: state.reason}}
	if capture != nil {
		response.pages = capture.pages
		if len(capture.pages) > 0 {
			response.collection.Method = "browser"
		}

		state.limited = state.limited || capture.limited
	}

	switch {
	case errors.Is(err, context.DeadlineExceeded):
		response.collection.Reason = "timeout"
	case errors.Is(err, context.Canceled):
		response.collection.Reason = "canceled"
	case state.limited:
		response.collection.Reason = reviewReasonLimited
	case err != nil:
		response.collection.Reason = "extraction_error"
	case response.collection.Reason == "":
		response.collection.Reason = "scroll_limit"
	}

	return response, domReviews, err
}
