package gmaps

import (
	"context"
	"fmt"
	"log"
	"net/url"
	"strings"
	"time"
	"uuid"

	"github.com/gosom/scrapemate"

	"github.com/gosom/google-maps-scraper/exiter"
)

type PlaceJobOptions func(*PlaceJob)

type PlaceJob struct {
	scrapemate.Job

	UsageInResults          bool
	ExtractEmail            bool
	ExitMonitor             exiter.Exiter
	ExtractExtraReviews     bool
	WriterManagedCompletion bool
}

func NewPlaceJob(parentID, langCode, u string, extractEmail, extraExtraReviews bool, opts ...PlaceJobOptions) *PlaceJob {
	const (
		defaultPrio       = scrapemate.PriorityMedium
		defaultMaxRetries = 3
	)

	u = sanitizePlaceURL(u)

	job := PlaceJob{
		Job: scrapemate.Job{
			ID:         uuid.NewV4().String(),
			ParentID:   parentID,
			Method:     requestMethodGet,
			URL:        u,
			URLParams:  map[string]string{languageQueryParam: langCode},
			MaxRetries: defaultMaxRetries,
			Priority:   defaultPrio,
		},
	}

	job.UsageInResults = true
	job.ExtractEmail = extractEmail
	job.ExtractExtraReviews = extraExtraReviews

	for _, opt := range opts {
		opt(&job)
	}

	return &job
}

// sanitizePlaceURL rewrites the dot-dot segment in a canonical Google Maps
// place URL so RFC 3986 path normalization cannot remove the "/maps/place/"
// marker. The URL is parsed only for validation; replacement operates on the
// raw string to preserve the Maps data payload byte-for-byte.
func sanitizePlaceURL(rawURL string) string {
	const (
		placeMarker     = "/maps/place/../data="
		sanitizedMarker = "/maps/place/_/data="
	)

	parsedURL, err := url.Parse(rawURL)
	if err != nil || parsedURL.Scheme != "https" || parsedURL.User != nil || parsedURL.Port() != "" ||
		!strings.EqualFold(parsedURL.Hostname(), "www.google.com") {
		return rawURL
	}

	if strings.Count(parsedURL.EscapedPath(), placeMarker) != 1 {
		return rawURL
	}

	markerIndex := strings.Index(rawURL, placeMarker)
	if markerIndex < 0 {
		return rawURL
	}

	return rawURL[:markerIndex] + sanitizedMarker + rawURL[markerIndex+len(placeMarker):]
}

func WithPlaceJobExitMonitor(exitMonitor exiter.Exiter) PlaceJobOptions {
	return func(j *PlaceJob) {
		j.ExitMonitor = exitMonitor
	}
}

func WithPlaceJobWriterManagedCompletion() PlaceJobOptions {
	return func(j *PlaceJob) {
		j.WriterManagedCompletion = true
	}
}

func (j *PlaceJob) ProcessOnFetchError() bool {
	return true
}

func (j *PlaceJob) Process(_ context.Context, resp *scrapemate.Response) (any, []scrapemate.IJob, error) {
	defer func() {
		resp.Document = nil
		resp.Body = nil
		resp.Meta = nil
	}()

	if resp.Error != nil {
		if j.ExitMonitor != nil {
			j.ExitMonitor.IncrPlacesCompleted(1)
		}

		return nil, nil, resp.Error
	}

	raw, ok := resp.Meta["json"].([]byte)
	if !ok {
		if j.ExitMonitor != nil {
			j.ExitMonitor.IncrPlacesCompleted(1)
		}

		return nil, nil, fmt.Errorf("could not convert to []byte")
	}

	entry, err := EntryFromJSON(raw)
	if err != nil {
		if j.ExitMonitor != nil {
			j.ExitMonitor.IncrPlacesCompleted(1)
		}

		return nil, nil, err
	}

	entry.ID = j.ParentID

	if entry.Link == "" {
		entry.Link = j.GetURL()
	}

	// Handle RPC-based reviews
	allReviewsRaw, ok := resp.Meta["reviews_raw"].(FetchReviewsResponse)
	if ok && len(allReviewsRaw.pages) > 0 {
		entry.AddExtraReviews(allReviewsRaw.pages)
		enrichKnownReviews(entry.UserReviews, entry.UserReviewsExtended)
		entry.UserReviewsExtended = dedupeDOMReviewsAgainstPrimary(entry.UserReviews, entry.UserReviewsExtended)
	}

	// Handle DOM-based reviews (fallback)
	domReviews, ok := resp.Meta["dom_reviews"].([]DOMReview)
	if ok && len(domReviews) > 0 {
		convertedReviews := ConvertDOMReviewsToReviews(domReviews)
		enrichKnownReviews(entry.UserReviews, convertedReviews)

		deduped := dedupeDOMReviewsAgainstPrimary(entry.UserReviews, convertedReviews)
		if len(deduped) != len(convertedReviews) {
			log.Printf("DOM reviews: dropped %d of %d already present in user_reviews",
				len(convertedReviews)-len(deduped), len(convertedReviews))
		}

		entry.UserReviewsExtended = appendUniqueReviews(entry.UserReviewsExtended, deduped)
	}

	if j.ExtractExtraReviews {
		outcome, _ := resp.Meta["review_collection"].(ReviewCollection)
		if outcome.Method == "" {
			outcome.Method = "none"
		}

		entry.finishReviewCollection(outcome)
	}

	collectedReviews := len(entry.UserReviews) + len(entry.UserReviewsExtended)
	if j.ExtractExtraReviews && collectedReviews < entry.ReviewCount {
		log.Printf("Warning: incomplete review collection for %q: collected %d of %d reported reviews",
			entry.Title, collectedReviews, entry.ReviewCount)
	}

	if j.ExtractEmail && entry.IsWebsiteValidForEmail() {
		opts := []EmailExtractJobOptions{}
		if j.ExitMonitor != nil {
			opts = append(opts, WithEmailJobExitMonitor(j.ExitMonitor))
		}

		if j.WriterManagedCompletion {
			opts = append(opts, WithEmailJobWriterManagedCompletion())
		}

		emailJob := NewEmailJob(j.ID, &entry, opts...)

		j.UsageInResults = false

		return nil, []scrapemate.IJob{emailJob}, nil
	} else if j.ExitMonitor != nil && !j.WriterManagedCompletion {
		j.ExitMonitor.IncrPlacesCompleted(1)
	}

	return &entry, nil, err
}

func (j *PlaceJob) BrowserActions(ctx context.Context, page scrapemate.BrowserPage) scrapemate.Response {
	var (
		resp    scrapemate.Response
		capture *browserReviewCapture
	)
	if j.ExtractExtraReviews {
		capture = startReviewCapture(page)
		defer capture.close()
	}

	pageResponse, err := page.Goto(j.GetURL(), scrapemate.WaitUntilDOMContentLoaded)
	if err != nil {
		resp.Error = err

		return resp
	}

	clickRejectCookiesIfRequired(page)

	const defaultTimeout = 5 * time.Second

	// Ignore WaitForURL errors — Google Maps may redirect slowly especially via proxy
	_ = page.WaitForURL(page.URL(), defaultTimeout)

	resp.URL = pageResponse.URL
	resp.StatusCode = pageResponse.StatusCode
	resp.Headers = pageResponse.Headers

	raw, err := j.extractJSON(page)
	if err != nil {
		resp.Error = err

		return resp
	}

	if resp.Meta == nil {
		resp.Meta = make(map[string]any)
	}

	resp.Meta["json"] = raw

	if j.ExtractExtraReviews {
		reviewCount := j.getReviewCount(raw)
		if reviewCount > 0 { // download reviews for any place that has them
			params := fetchReviewsParams{
				page:        page,
				mapURL:      page.URL(),
				reviewCount: reviewCount,
				capture:     capture,
			}

			// Observe the anonymous page's own current RPC requests and keep DOM
			// reviews when the browser does not expose a structured response.
			rpcData, domReviews, err := FetchReviewsWithFallback(ctx, params)
			resp.Meta["review_collection"] = rpcData.collection

			if err != nil {
				fmt.Printf("Warning: review extraction failed: %v\n", err)
			}

			if len(rpcData.pages) > 0 {
				resp.Meta["reviews_raw"] = rpcData
			}

			if len(domReviews) > 0 {
				resp.Meta["dom_reviews"] = domReviews
			}
		}
	}

	return resp
}

func (j *PlaceJob) getRaw(ctx context.Context, page scrapemate.BrowserPage) (any, error) {
	for {
		select {
		case <-ctx.Done():
			return nil, fmt.Errorf("timeout while getting raw data: %w", ctx.Err())
		default:
			raw, err := page.Eval(js)
			if err != nil {
				// Continue retrying on error
				<-time.After(time.Millisecond * 200)
				continue
			}

			// Check for valid non-null result.
			// JS null may arrive as nil, and empty strings are not useful here.
			if raw == nil {
				<-time.After(time.Millisecond * 200)
				continue
			}

			// If it's a string, make sure it's not empty
			if str, ok := raw.(string); ok {
				if str == "" {
					<-time.After(time.Millisecond * 200)
					continue
				}
			}

			return raw, nil
		}
	}
}

func (j *PlaceJob) extractJSON(page scrapemate.BrowserPage) ([]byte, error) {
	const maxRetries = 2

	for attempt := range maxRetries {
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		rawI, err := j.getRaw(ctx, page)

		cancel()

		if err != nil {
			// On timeout, try reloading the page
			if attempt < maxRetries-1 {
				if reloadErr := page.Reload(scrapemate.WaitUntilDOMContentLoaded); reloadErr == nil {
					continue
				}
			}

			return nil, err
		}

		if rawI == nil {
			if attempt < maxRetries-1 {
				if reloadErr := page.Reload(scrapemate.WaitUntilDOMContentLoaded); reloadErr == nil {
					continue
				}
			}

			return nil, fmt.Errorf("APP_INITIALIZATION_STATE data not found")
		}

		raw, ok := rawI.(string)
		if !ok {
			return nil, fmt.Errorf("could not convert to string, got type %T", rawI)
		}

		const prefix = `)]}'`

		raw = strings.TrimSpace(strings.TrimPrefix(raw, prefix))

		return []byte(raw), nil
	}

	return nil, fmt.Errorf("APP_INITIALIZATION_STATE data not found after retries")
}

func (j *PlaceJob) getReviewCount(data []byte) int {
	tmpEntry, err := EntryFromJSON(data, true)
	if err != nil {
		return 0
	}

	return tmpEntry.ReviewCount
}

func (j *PlaceJob) UseInResults() bool {
	return j.UsageInResults
}

const js = `
(function() {
	if (!window.APP_INITIALIZATION_STATE || !window.APP_INITIALIZATION_STATE[3]) {
		return null;
	}
	const appState = window.APP_INITIALIZATION_STATE[3];
	
	// Search all properties of appState for arrays containing JSON strings
	for (const key of Object.keys(appState)) {
		const arr = appState[key];
		if (Array.isArray(arr)) {
			// Check indices 6 and 5 (where place data typically is)
			for (const idx of [6, 5]) {
				const item = arr[idx];
				if (typeof item === 'string' && item.startsWith(")]}'")) {
					return item;
				}
			}
		}
	}
	return null;
})()
`
